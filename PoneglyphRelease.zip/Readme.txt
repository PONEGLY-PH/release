포네그리프: https://ponegly.ph
조합식/세이브코드 저장, 로드 외에도 여러 가지 유틸리티를 추가하려 준비 중에 있습니다.

<사용방법>
1. WebView2 런타임 설치
- https://blog.naver.com/ponegly-ph/223119044514

2. Poneglyph.Desktop.exe 실행 후 게임 플레이

사진과 함께 더 자세한 사용방법을 보고 싶으시면 아래 링크로 접속해 주세요
- https://blog.naver.com/ponegly-ph/223119045877